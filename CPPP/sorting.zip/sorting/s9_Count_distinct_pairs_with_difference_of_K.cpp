#include <bits/stdc++.h>
using namespace std;

int BS(int arr[], int X, int low, int N)
{
	int high = N - 1;
	int ans = N;
	while (low <= high) {
		int mid = low + (high - low) / 2;
		if (arr[mid] >= X) {
			ans = mid;
			high = mid - 1;
		}
		else
			low = mid + 1;
	}
	return ans;
}
int countPairsWithDiffK(int arr[], int N, int k)
{
	int count = 0;
	sort(arr, arr + N);
	for (int i = 0; i < N; ++i) {
		int X = BS(arr, arr[i] + k, i + 1, N);
		if (X != N) {
			int Y = BS(arr, arr[i] + k + 1, i + 1, N);
			count += Y - X;
		}
	}

	return count;
}
int main()
{
	int arr[] = { 1, 3, 5, 8, 6, 4, 6 };
	int n = sizeof(arr) / sizeof(arr[0]);
	int k = 2;
	cout << "Count of pairs with given diff is "
		<< countPairsWithDiffK(arr, n, k);

	return 0;
}


