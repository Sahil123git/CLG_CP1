//You are provided with marks of N students in Physics, Chemistry and Maths.
//Perform the following 3 operations:
//Sort the students in Ascending order of their Physics marks.
//Once this is done, sort the students having same marks in Physics in the descending order of their Chemistry marks.
//Once this is also done, sort the students having same marks in Physics and Chemistry in the ascending order of their Maths marks.
 static bool mycomp(vector<int> a,vector<int> b){
        if(a[0] == b[0] && a[1] == b[1]) return a[2] < b[2];
        else if(a[0] == b[0] ) return a[1] > b[1];
        return a[0] < b[0] ;
    }
    void customSort (int phy[], int chem[], int math[], int N)
    {
        // your code here
         vector<vector<int>> stu(N,vector<int>(3));
        for(int i = 0 ; i < N ; i++){
            stu[i][0] = phy[i];
            stu[i][1] = chem[i];
            stu[i][2] = math[i];
        }

        sort(stu.begin(),stu.end(),mycomp);
        for(int i = 0 ; i < N ; i++){
            phy[i] = stu[i][0] , chem[i] = stu[i][1] , math[i] = stu[i][2];
    }
